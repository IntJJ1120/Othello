package components;

import controller.GameController;
import model.*;
import view.GameFrame;

import java.awt.*;

public class ChessGridComponent extends BasicComponent {
    public static int chessSize;
    public static int gridSize;
    public static Color gridColor = new Color(255, 150, 50);

    private ChessPiece chessPiece;
    private int row;
    private int col;

    public ChessGridComponent(int row, int col) {
        this.setSize(gridSize, gridSize);
        this.row = row;
        this.col = col;
    }
    @Override
    public void onMouseClicked() {
        System.out.printf("%s clicked (%d, %d)\n", GameFrame.controller.getCurrentPlayer(), row, col);
        if (GameFrame.controller.canClick(row, col)) {
            if (this.chessPiece == null) {
                this.chessPiece = GameFrame.controller.getCurrentPlayer();
                for(int q = 1; q < 8-col-1;q++) {
                    if (GameFrame.controller.getGamePanel().getChessGrids()[row][col+q].getChessPiece()==
                            ((GameFrame.controller.getCurrentPlayer() == ChessPiece.BLACK) ? ChessPiece.WHITE : ChessPiece.BLACK))
                    {
                        if (GameFrame.controller.getGamePanel().getChessGrids()[row][col+q+1].getChessPiece()
                                ==GameFrame.controller.getCurrentPlayer()){
                    for(int e=col;e<col+q+1;e++){
                       GameFrame.controller.getGamePanel().getChessGrids()[row][e].chessPiece = GameFrame.controller.getCurrentPlayer();
                            GameFrame.controller.getGamePanel().getChessGrids()[row][e].repaint();}}
                    }
                    else{
                        break;
                    }
                }
                for (int q = 1; q < 8- row -1; q++) {
                    if (GameFrame.controller.getGamePanel().getChessGrids()[row + q][col].getChessPiece() == ((GameFrame.controller.getCurrentPlayer() == ChessPiece.BLACK) ? ChessPiece.WHITE : ChessPiece.BLACK)) {
                        if (GameFrame.controller.getGamePanel().getChessGrids()[row +q+1][col].getChessPiece()
                                == GameFrame.controller.getCurrentPlayer()) {
                    for(int e=row;e<row+q+1;e++){
                        GameFrame.controller.getGamePanel().getChessGrids()[e][col].chessPiece = GameFrame.controller.getCurrentPlayer();
                            GameFrame.controller.getGamePanel().getChessGrids()[e][col].repaint();  }}
                    } else{
                        break;
                    }
                }
                for (int q = 1; q < row; q++) {
                    if (GameFrame.controller.getGamePanel().getChessGrids()[row- q][col].getChessPiece() == ((GameFrame.controller.getCurrentPlayer() == ChessPiece.BLACK) ? ChessPiece.WHITE : ChessPiece.BLACK)) {
                        if (GameFrame.controller.getGamePanel().getChessGrids()[row-q-1][col].getChessPiece()
                                ==GameFrame.controller.getCurrentPlayer()) {
                    for(int e=row;e>row-q-1;e--){
                       GameFrame.controller.getGamePanel().getChessGrids()[e][col].chessPiece = GameFrame.controller.getCurrentPlayer();
                        GameFrame.controller.getGamePanel().getChessGrids()[e][col].repaint();  }}
                    } else{
                        break;
                    }
                }
                for (int q = 1; q < col; q++) {
                    if (GameFrame.controller.getGamePanel().getChessGrids()[row][col-q].getChessPiece()== ((GameFrame.controller.getCurrentPlayer() == ChessPiece.BLACK) ? ChessPiece.WHITE : ChessPiece.BLACK)) {
                        if (GameFrame.controller.getGamePanel().getChessGrids()[row][col-q-1].getChessPiece()
                                == GameFrame.controller.getCurrentPlayer()) {
                    for(int e=col;e>col-q-1;e--){
                        GameFrame.controller.getGamePanel().getChessGrids()[row][e].chessPiece = GameFrame.controller.getCurrentPlayer();
                        GameFrame.controller.getGamePanel().getChessGrids()[row][e].repaint();}}
                    } else{
                        break;
                    }
                }
                for (int q = 1; q<col&q<row; q++) {
                    if (GameFrame.controller.getGamePanel().getChessGrids()[row-q][col-q].getChessPiece() ==((GameFrame.controller.getCurrentPlayer() == ChessPiece.BLACK) ? ChessPiece.WHITE : ChessPiece.BLACK)) {
                        if (GameFrame.controller.getGamePanel().getChessGrids()[row-q-1][col-q-1].getChessPiece()
                                ==GameFrame.controller.getCurrentPlayer()) {
                            int e=col;int r=row;
                    while(e>col-q-1&r>row-q-1){
                      GameFrame.controller.getGamePanel().getChessGrids()[r][e].chessPiece = GameFrame.controller.getCurrentPlayer();
                        e--;
                        r--;
                        GameFrame.controller.getGamePanel().getChessGrids()[r][e].repaint();
                    }
                        }
                    } else{
                        break;
                    }
                }
                for (int q = 1; q<8-row-1&q<8-col-1; q++) {
                    if (GameFrame.controller.getGamePanel().getChessGrids()[row+q][col+q].getChessPiece() == ((GameFrame.controller.getCurrentPlayer() == ChessPiece.BLACK) ? ChessPiece.WHITE : ChessPiece.BLACK)) {
                        if (GameFrame.controller.getGamePanel().getChessGrids()[row+q+1][col+q+1].getChessPiece()
                                ==GameFrame.controller.getCurrentPlayer()) {
                            int e=row;int r=col;
                    while(e<q+row+1&r<q+col+1){
                        GameFrame.controller.getGamePanel().getChessGrids()[e][r].chessPiece = GameFrame.controller.getCurrentPlayer();
                        e++;
                        r++;
                        GameFrame.controller.getGamePanel().getChessGrids()[e][r].repaint();
                    }repaint();
                        }
                    } else{
                        break;
                    }
                }
                for (int q = 1; q<8-row-1&q<col; q++) {
                    if (GameFrame.controller.getGamePanel().getChessGrids()[row+q][col-q].getChessPiece() == ((GameFrame.controller.getCurrentPlayer() == ChessPiece.BLACK) ? ChessPiece.WHITE : ChessPiece.BLACK)) {
                        if(GameFrame.controller.getGamePanel().getChessGrids()[row+q+1][col-1-q].getChessPiece()
                                ==GameFrame.controller.getCurrentPlayer()){
                            int e=row;int r=col;
                    while(e<q+1+row&r>col-q-1){
                        GameFrame.controller.getGamePanel().getChessGrids()[e][r].chessPiece = GameFrame.controller.getCurrentPlayer();
                        e++;
                        r--;
                        GameFrame.controller.getGamePanel().getChessGrids()[e][r].repaint();
                    }
                        }
                    } else{
                        break;
                    }
                }
                for (int q = 1; q<row&q<8-col-1; q++) {
                    if (GameFrame.controller.getGamePanel().getChessGrids()[row-q][col+q].getChessPiece()==((GameFrame.controller.getCurrentPlayer() == ChessPiece.BLACK) ? ChessPiece.WHITE : ChessPiece.BLACK)) {
                        if (GameFrame.controller.getGamePanel().getChessGrids()[row-q-1][col+q+1].getChessPiece()
                                ==GameFrame.controller.getCurrentPlayer()) {
                            int e=row;int r=col;
                    while(e>row-q-1&r<q+1+col){
                        GameFrame.controller.getGamePanel().getChessGrids()[e][r].chessPiece = GameFrame.controller.getCurrentPlayer();
                        e--;
                        r++;GameFrame.controller.getGamePanel().getChessGrids()[e][r].repaint();
                    }
                        }
                    } else{
                        break;
                    }
                }
                GameFrame.controller.swapPlayer();
            }
            repaint();
        }
//
//        if(GameFrame.controller.getGamePanel().GameOver(GameFrame.controller.getCurrentPlayer())){
//            GameFrame.controller.setCurrentPlayer(GameFrame.controller.getCurrentPlayer());
//            GameFrame.controller.getStatusPanel().setPlayerText(GameFrame.controller.getCurrentPlayer().name());
//            if(GameFrame.controller.getGamePanel().GameOver(GameFrame.controller.getCurrentPlayer())){
//                GameFrame.controller.compareNumberGetWinner();
//            }
//            else{
//            if (this.chessPiece == null) {
//                this.chessPiece = GameFrame.controller.getCurrentPlayer();
//                for(int q = 1; q < 8-col-1;q++) {
//                    if (GameFrame.controller.getGamePanel().getChessGrids()[row][col+q].getChessPiece()==
//                            ((GameFrame.controller.getCurrentPlayer() == ChessPiece.BLACK) ? ChessPiece.WHITE : ChessPiece.BLACK))
//                    {
//                        if (GameFrame.controller.getGamePanel().getChessGrids()[row][col+q+1].getChessPiece()
//                                ==GameFrame.controller.getCurrentPlayer()){
//                            for(int e=col;e<col+q+1;e++){
//                                GameFrame.controller.getGamePanel().getChessGrids()[row][e].chessPiece = GameFrame.controller.getCurrentPlayer();
//                                GameFrame.controller.getGamePanel().getChessGrids()[row][e].repaint();}}
//                    }
//                    else{
//                        break;
//                    }
//                }
//                for (int q = 1; q < 8- row -1; q++) {
//                    if (GameFrame.controller.getGamePanel().getChessGrids()[row + q][col].getChessPiece() == ((GameFrame.controller.getCurrentPlayer() == ChessPiece.BLACK) ? ChessPiece.WHITE : ChessPiece.BLACK)) {
//                        if (GameFrame.controller.getGamePanel().getChessGrids()[row +q+1][col].getChessPiece()
//                                == GameFrame.controller.getCurrentPlayer()) {
//                            for(int e=row;e<row+q+1;e++){
//                                GameFrame.controller.getGamePanel().getChessGrids()[e][col].chessPiece = GameFrame.controller.getCurrentPlayer();
//                                GameFrame.controller.getGamePanel().getChessGrids()[e][col].repaint();  }}
//                    } else{
//                        break;
//                    }
//                }
//                for (int q = 1; q < row; q++) {
//                    if (GameFrame.controller.getGamePanel().getChessGrids()[row- q][col].getChessPiece() == ((GameFrame.controller.getCurrentPlayer() == ChessPiece.BLACK) ? ChessPiece.WHITE : ChessPiece.BLACK)) {
//                        if (GameFrame.controller.getGamePanel().getChessGrids()[row-q-1][col].getChessPiece()
//                                ==GameFrame.controller.getCurrentPlayer()) {
//                            for(int e=row;e>row-q-1;e--){
//                                GameFrame.controller.getGamePanel().getChessGrids()[e][col].chessPiece = GameFrame.controller.getCurrentPlayer();
//                                GameFrame.controller.getGamePanel().getChessGrids()[e][col].repaint();  }}
//                    } else{
//                        break;
//                    }
//                }
//                for (int q = 1; q < col; q++) {
//                    if (GameFrame.controller.getGamePanel().getChessGrids()[row][col-q].getChessPiece()== ((GameFrame.controller.getCurrentPlayer() == ChessPiece.BLACK) ? ChessPiece.WHITE : ChessPiece.BLACK)) {
//                        if (GameFrame.controller.getGamePanel().getChessGrids()[row][col-q-1].getChessPiece()
//                                == GameFrame.controller.getCurrentPlayer()) {
//                            for(int e=col;e>col-q-1;e--){
//                                GameFrame.controller.getGamePanel().getChessGrids()[row][e].chessPiece = GameFrame.controller.getCurrentPlayer();
//                                GameFrame.controller.getGamePanel().getChessGrids()[row][e].repaint();}}
//                    } else{
//                        break;
//                    }
//                }
//                for (int q = 1; q<col&q<row; q++) {
//                    if (GameFrame.controller.getGamePanel().getChessGrids()[row-q][col-q].getChessPiece() ==((GameFrame.controller.getCurrentPlayer() == ChessPiece.BLACK) ? ChessPiece.WHITE : ChessPiece.BLACK)) {
//                        if (GameFrame.controller.getGamePanel().getChessGrids()[row-q-1][col-q-1].getChessPiece()
//                                ==GameFrame.controller.getCurrentPlayer()) {
//                            int e=col;int r=row;
//                            while(e>col-q-1&r>row-q-1){
//                                GameFrame.controller.getGamePanel().getChessGrids()[r][e].chessPiece = GameFrame.controller.getCurrentPlayer();
//                                e--;
//                                r--;
//                                GameFrame.controller.getGamePanel().getChessGrids()[r][e].repaint();
//                            }
//                        }
//                    } else{
//                        break;
//                    }
//                }
//                for (int q = 1; q<8-row-1&q<8-col-1; q++) {
//                    if (GameFrame.controller.getGamePanel().getChessGrids()[row+q][col+q].getChessPiece() == ((GameFrame.controller.getCurrentPlayer() == ChessPiece.BLACK) ? ChessPiece.WHITE : ChessPiece.BLACK)) {
//                        if (GameFrame.controller.getGamePanel().getChessGrids()[row+q+1][col+q+1].getChessPiece()
//                                ==GameFrame.controller.getCurrentPlayer()) {
//                            int e=row;int r=col;
//                            while(e<q+row+1&r<q+col+1){
//                                GameFrame.controller.getGamePanel().getChessGrids()[e][r].chessPiece = GameFrame.controller.getCurrentPlayer();
//                                e++;
//                                r++;
//                                GameFrame.controller.getGamePanel().getChessGrids()[e][r].repaint();
//                            }repaint();
//                        }
//                    } else{
//                        break;
//                    }
//                }
//                for (int q = 1; q<8-row-1&q<col; q++) {
//                    if (GameFrame.controller.getGamePanel().getChessGrids()[row+q][col-q].getChessPiece() == ((GameFrame.controller.getCurrentPlayer() == ChessPiece.BLACK) ? ChessPiece.WHITE : ChessPiece.BLACK)) {
//                        if(GameFrame.controller.getGamePanel().getChessGrids()[row+q+1][col-1-q].getChessPiece()
//                                ==GameFrame.controller.getCurrentPlayer()){
//                            int e=row;int r=col;
//                            while(e<q+1+row&r>col-q-1){
//                                GameFrame.controller.getGamePanel().getChessGrids()[e][r].chessPiece = GameFrame.controller.getCurrentPlayer();
//                                e++;
//                                r--;
//                                GameFrame.controller.getGamePanel().getChessGrids()[e][r].repaint();
//                            }
//                        }
//                    } else{
//                        break;
//                    }
//                }
//                for (int q = 1; q<row&q<8-col-1; q++) {
//                    if (GameFrame.controller.getGamePanel().getChessGrids()[row-q][col+q].getChessPiece()==((GameFrame.controller.getCurrentPlayer() == ChessPiece.BLACK) ? ChessPiece.WHITE : ChessPiece.BLACK)) {
//                        if (GameFrame.controller.getGamePanel().getChessGrids()[row-q-1][col+q+1].getChessPiece()
//                                ==GameFrame.controller.getCurrentPlayer()) {
//                            int e=row;int r=col;
//                            while(e>row-q-1&r<q+1+col){
//                                GameFrame.controller.getGamePanel().getChessGrids()[e][r].chessPiece = GameFrame.controller.getCurrentPlayer();
//                                e--;
//                                r++;GameFrame.controller.getGamePanel().getChessGrids()[e][r].repaint();
//                            }
//                        }
//                    } else{
//                        break;
//                    }
//                }
//                GameFrame.controller.swapPlayer();
//            }
//            repaint();
//
//        }}
    }


    public ChessPiece getChessPiece() {
        return chessPiece;
    }

    public void setChessPiece(ChessPiece chessPiece) {
        this.chessPiece = chessPiece;
    }

    public int getRow() {
        return row;
    }

    public int getCol() {
        return col;
    }

    public void drawPiece(Graphics g) {
        g.setColor(gridColor);
        g.fillRect(1, 1, this.getWidth() - 2, this.getHeight() - 2);
        if (this.chessPiece != null) {
            g.setColor(chessPiece.getColor());
            g.fillOval((gridSize - chessSize) / 2, (gridSize - chessSize) / 2, chessSize, chessSize);
        }
    }
    @Override
    public void paintComponent(Graphics g) {
        super.printComponents(g);
        drawPiece(g);
    }
}
