package view;

import components.ChessGridComponent;
import model.ChessPiece;

import javax.swing.*;
import java.awt.*;

public class ChessBoardPanel extends JPanel {
    private final int CHESS_COUNT = 8;
    private ChessGridComponent[][] chessGrids;

    public ChessBoardPanel(int width, int height) {
        this.setVisible(true);
        this.setFocusable(true);
        this.setLayout(null);
        this.setBackground(Color.BLACK);
        int length = Math.min(width, height);
        this.setSize(length, length);
        ChessGridComponent.gridSize = length / CHESS_COUNT;
        ChessGridComponent.chessSize = (int) (ChessGridComponent.gridSize * 0.8);
        System.out.printf("width = %d height = %d gridSize = %d chessSize = %d\n",
                width, height, ChessGridComponent.gridSize, ChessGridComponent.chessSize);

        initialChessGrids();//return empty chessboard
        initialGame();//add initial four chess

        repaint();
    }

    /**
     * set an empty chessboard
     */
    public ChessGridComponent[][] getChessGrids() {
        return chessGrids;
    }

    public ChessGridComponent[][] getChessGridComponent() {
        return chessGrids;
    }

    public void initialChessGrids() {
        chessGrids = new ChessGridComponent[CHESS_COUNT][CHESS_COUNT];
        //draw all chess grids
        for (int i = 0; i < CHESS_COUNT; i++) {
            for (int j = 0; j < CHESS_COUNT; j++) {
                ChessGridComponent gridComponent = new ChessGridComponent(i, j);
                gridComponent.setLocation(j * ChessGridComponent.gridSize, i * ChessGridComponent.gridSize);
                chessGrids[i][j] = gridComponent;
                this.add(chessGrids[i][j]);
            }
        }
    }

    /**
     * initial origin four chess
     */
    public void initialGame() {
        chessGrids[3][3].setChessPiece(ChessPiece.BLACK);
        chessGrids[3][4].setChessPiece(ChessPiece.WHITE);
        chessGrids[4][3].setChessPiece(ChessPiece.WHITE);
        chessGrids[4][4].setChessPiece(ChessPiece.BLACK);
    }


    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, this.getWidth(), this.getHeight());
    }

    public ChessPiece changeChess(ChessPiece currentPlayer) {
        ChessPiece a = (currentPlayer == ChessPiece.BLACK) ? ChessPiece.WHITE : ChessPiece.BLACK;
        return a;
    }

    public boolean canClickGrid(int row, int col, ChessPiece currentPlayer) {
        boolean b = false;
        for (int q = 1; q < 8 - col - 1; q++) {
            if (this.chessGrids[row][col + q].getChessPiece() == this.changeChess(currentPlayer)) {
                if (this.chessGrids[row][col + q + 1].getChessPiece() == currentPlayer) {
                    b = true;
                }
            } else {
                break;
            }
        }
        for (int q = 1; q < 8 - row - 1; q++) {
            if (this.chessGrids[row + q][col].getChessPiece() == this.changeChess(currentPlayer)) {
                if (this.chessGrids[row + q + 1][col].getChessPiece() == currentPlayer) {
                    b = true;
                }
            } else {
                break;
            }
        }
        for (int q = 1; q < row; q++) {
            if (this.chessGrids[row - q][col].getChessPiece() == this.changeChess(currentPlayer)) {
                if (this.chessGrids[row - q - 1][col].getChessPiece() == currentPlayer) {
                    b = true;
                }
            } else {
                break;
            }
        }
        for (int q = 1; q < col; q++) {
            if (this.chessGrids[row][col - q].getChessPiece() == this.changeChess(currentPlayer)) {
                if (this.chessGrids[row][col - q - 1].getChessPiece() == currentPlayer) {
                    b = true;
                }
            } else {
                break;
            }
        }
        for (int q = 1; q < col & q < row; q++) {
            if (this.chessGrids[row - q][col - q].getChessPiece() == this.changeChess(currentPlayer)) {
                if (this.chessGrids[row - q - 1][col - q - 1].getChessPiece() == currentPlayer) {
                    b = true;
                    int e = col;
                    int r = row;
                }
            } else {
                break;
            }
        }
        for (int q = 1; q < 8 - row - 1 & q < 8 - col - 1; q++) {
            if (this.chessGrids[row + q][col + q].getChessPiece() == this.changeChess(currentPlayer)) {
                if (this.chessGrids[row + q + 1][col + q + 1].getChessPiece() == currentPlayer) {
                    int e = row;
                    int r = col;
                    b = true;
                }
            } else {
                break;
            }
        }
        for (int q = 1; q < 8 - row - 1 & q < col; q++) {
            if (this.chessGrids[row + q][col - q].getChessPiece() == this.changeChess(currentPlayer)) {
                if (this.chessGrids[row + q + 1][col - 1 - q].getChessPiece() == currentPlayer) {
                    int e = row;
                    int r = col;
                    b = true;
                }
            } else {
                break;
            }
        }
        for (int q = 1; q < row & q < 8 - col - 1; q++) {
            if (this.chessGrids[row - q][col + q].getChessPiece() == this.changeChess(currentPlayer)) {
                if (this.chessGrids[row - q - 1][col + q + 1].getChessPiece() == currentPlayer) {
                    b = true;
                    int e = row;
                    int r = col;
                }
            } else {
                break;
            }
        }
        return b;
    }

    public boolean Filling() {
        boolean b = false;
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (this.chessGrids[i][j] != null) {
                    b = true;
                    break;
                }
            }
        }
        return b;
    }

    public boolean GameOver(ChessPiece currentPlayer) {
        boolean b =true;
        if (this.Filling()) {
            for (int row = 0; row < 8; row++) {
                for (int col = 0; col < 8; col++) {
                    for (int q = 1; q < 8 - col - 1; q++) {
                        if (this.chessGrids[row][col + q].getChessPiece() == this.changeChess(currentPlayer)) {
                            if (this.chessGrids[row][col + q + 1].getChessPiece() == currentPlayer) {
                                b =false;
                            }
                        } else {
                            break;
                        }
                    }
                    for (int q = 1; q < 8 - row - 1; q++) {
                        if (this.chessGrids[row + q][col].getChessPiece() == this.changeChess(currentPlayer)) {
                            if (this.chessGrids[row + q + 1][col].getChessPiece() == currentPlayer) {
                                b = false;
                            }
                        } else {
                            break;
                        }
                    }
                    for (int q = 1; q < row; q++) {
                        if (this.chessGrids[row - q][col].getChessPiece() == this.changeChess(currentPlayer)) {
                            if (this.chessGrids[row - q - 1][col].getChessPiece() == currentPlayer) {
                                b = false;
                            }
                        } else {
                            break;
                        }
                    }
                    for (int q = 1; q < col; q++) {
                        if (this.chessGrids[row][col - q].getChessPiece() == this.changeChess(currentPlayer)) {
                            if (this.chessGrids[row][col - q - 1].getChessPiece() == currentPlayer) {
                                b = false;
                            }
                        } else {
                            break;
                        }
                    }
                    for (int q = 1; q < col & q < row; q++) {
                        if (this.chessGrids[row - q][col - q].getChessPiece() == this.changeChess(currentPlayer)) {
                            if (this.chessGrids[row - q - 1][col - q - 1].getChessPiece() == currentPlayer) {
                                b = false;
                            }
                        } else {
                            break;
                        }
                    }
                    for (int q = 1; q < 8 - row - 1 & q < 8 - col - 1; q++) {
                        if (this.chessGrids[row + q][col + q].getChessPiece() == this.changeChess(currentPlayer)) {
                            if (this.chessGrids[row + q + 1][col + q + 1].getChessPiece() == currentPlayer) {
                                b = false;
                            }
                        } else {
                            break;
                        }
                    }
                    for (int q = 1; q < 8 - row - 1 & q < col; q++) {
                        if (this.chessGrids[row + q][col - q].getChessPiece() == this.changeChess(currentPlayer)) {
                            if (this.chessGrids[row + q + 1][col - 1 - q].getChessPiece() == currentPlayer) {
                                b = false;
                            }
                        } else {
                            break;
                        }
                    }
                    for (int q = 1; q < row & q < 8 - col - 1; q++) {
                        if (this.chessGrids[row - q][col + q].getChessPiece() == this.changeChess(currentPlayer)) {
                            if (this.chessGrids[row - q - 1][col + q + 1].getChessPiece() == currentPlayer) {
                                b = false;
                            }
                        } else {
                            break;
                        }
                    }
                }
            }

        } else {
              b=true;
        } return b;
    }
//    public String WinnerName( ChessPiece currentPlayer) {
//        boolean b=false;
//
//        for(int row=0;row<8;row++) {
//            for (int col = 0; col < 8; col++) {
//                for (int q = 1; q < 8 - col - 1; q++) {
//                    if (this.chessGrids[row][col + q].getChessPiece() == this.changeChess(currentPlayer)) {
//                        if (this.chessGrids[row][col + q + 1].getChessPiece() == currentPlayer) {
//                            b = true;
//                        }
//                    } else {
//                        break;
//                    }
//                }
//                for (int q = 1; q < 8 - row - 1; q++) {
//                    if (this.chessGrids[row + q][col].getChessPiece() == this.changeChess(currentPlayer)) {
//                        if (this.chessGrids[row + q + 1][col].getChessPiece() == currentPlayer) {
//                            b = true;
//                        }
//                    } else {
//                        break;
//                    }
//                }
//                for (int q = 1; q < row; q++) {
//                    if (this.chessGrids[row - q][col].getChessPiece() == this.changeChess(currentPlayer)) {
//                        if (this.chessGrids[row - q - 1][col].getChessPiece() == currentPlayer) {
//                            b = true;
//                        }
//                    } else {
//                        break;
//                    }
//                }
//                for (int q = 1; q < col; q++) {
//                    if (this.chessGrids[row][col - q].getChessPiece() == this.changeChess(currentPlayer)) {
//                        if (this.chessGrids[row][col - q - 1].getChessPiece() == currentPlayer) {
//                            b = true;
//                        }
//                    } else {
//                        break;
//                    }
//                }
//                for (int q = 1; q < col & q < row; q++) {
//                    if (this.chessGrids[row - q][col - q].getChessPiece() == this.changeChess(currentPlayer)) {
//                        if (this.chessGrids[row - q - 1][col - q - 1].getChessPiece() == currentPlayer) {
//                            b = true;
//                        }
//                    } else {
//                        break;
//                    }
//                }
//                for (int q = 1; q < 8 - row - 1 & q < 8 - col - 1; q++) {
//                    if (this.chessGrids[row + q][col + q].getChessPiece() == this.changeChess(currentPlayer)) {
//                        if (this.chessGrids[row + q + 1][col + q + 1].getChessPiece() == currentPlayer) {
//                            b = true;
//                        }
//                    } else {
//                        break;
//                    }
//                }
//                for (int q = 1; q < 8 - row - 1 & q < col; q++) {
//                    if (this.chessGrids[row + q][col - q].getChessPiece() == this.changeChess(currentPlayer)) {
//                        if (this.chessGrids[row + q + 1][col - 1 - q].getChessPiece() == currentPlayer) {
//                            b = true;
//                        }
//                    } else {
//                        break;
//                    }
//                }
//                for (int q = 1; q < row & q < 8 - col - 1; q++) {
//                    if (this.chessGrids[row - q][col + q].getChessPiece() == this.changeChess(currentPlayer)) {
//                        if (this.chessGrids[row - q - 1][col + q + 1].getChessPiece() == currentPlayer) {
//                            b = true;
//                        }
//                    } else {
//                        break;
//                    }
//                }
//            }}
//        if(b){
//            return currentPlayer.name();}
//        else{
//            return( (currentPlayer == ChessPiece.BLACK) ? ChessPiece.WHITE : ChessPiece.BLACK).name();}
//    }
    }


