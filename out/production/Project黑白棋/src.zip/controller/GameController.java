package controller;

import components.ChessGridComponent;
import model.ChessPiece;
import view.*;

import java.io.*;
import java.util.ArrayList;
import java.util.List;


public class GameController {
    private ChessBoardPanel gamePanel;
    private StatusPanel statusPanel;
    private ChessPiece currentPlayer;
    private int blackScore;
    private int whiteScore;

    public GameController(ChessBoardPanel gamePanel, StatusPanel statusPanel) {
        this.gamePanel = gamePanel;
        this.statusPanel = statusPanel;
        this.currentPlayer = ChessPiece.BLACK;
        blackScore = 2;
        whiteScore = 2;
    }

//    public void setCurrentPlayer(ChessPiece currentPlayer){
//        this.currentPlayer=(currentPlayer== ChessPiece.BLACK) ? ChessPiece.WHITE : ChessPiece.BLACK;
//    }

    public void swapPlayer() {
        blackScore =0;
        whiteScore =0;
        countScore();
        currentPlayer = (currentPlayer == ChessPiece.BLACK) ? ChessPiece.WHITE : ChessPiece.BLACK;
        statusPanel.setPlayerText(currentPlayer.name());
        statusPanel.setScoreText(blackScore, whiteScore);
    }

    public void Restart(){
        this.currentPlayer = ChessPiece.BLACK;
        blackScore = 2;
        whiteScore = 2;
        statusPanel.setPlayerText(currentPlayer.name());
        statusPanel.setScoreText(blackScore, whiteScore);


        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                this.gamePanel.getChessGridComponent()[i][j].setChessPiece(null);
                this.gamePanel.getChessGridComponent()[i][j].repaint();
            }
        }this.gamePanel.getChessGridComponent()[3][3].setChessPiece(ChessPiece.BLACK);
        this.gamePanel.getChessGridComponent()[3][4].setChessPiece(ChessPiece.WHITE);
        this.gamePanel.getChessGridComponent()[4][3].setChessPiece(ChessPiece.WHITE);
        this.gamePanel.getChessGridComponent()[4][4].setChessPiece(ChessPiece.BLACK);
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                this.gamePanel.getChessGridComponent()[i][j].repaint();
            }
        }
    }

    public void countScore() {
        for(int i=0;i<8;i++) {
            for (int j = 0; j < 8; j++) {
                if(this.getGamePanel().getChessGridComponent()[i][j].getChessPiece()==ChessPiece.BLACK){
                    blackScore++;
                }
                else if(this.getGamePanel().getChessGridComponent()[i][j].getChessPiece()==ChessPiece.WHITE){
                    whiteScore++;
                }
            }
        }
    }

//    public void compareNumberGetWinner(){
//        if(this.blackScore>this.whiteScore){
//            statusPanel.setWinnerText("Black");
//        }
//        else if(this.blackScore<this.whiteScore){
//            statusPanel.setWinnerText("White");
//        }
//        else{
//            statusPanel.setWinnerText("Equal");
//        }
//    }

    public ChessPiece getCurrentPlayer() {
        return currentPlayer;
    }

    public ChessBoardPanel getGamePanel() {
        return gamePanel;
    }
    public StatusPanel getStatusPanel() {
        return statusPanel;
    }


    public void setGamePanel(ChessBoardPanel gamePanel) {
        this.gamePanel = gamePanel;
    }


    public void readFileData(String fileName) {
        //todo: read date from file
        List<String> fileData = new ArrayList<>();
        try {
            FileReader fileReader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                fileData.add(line);
            }
            fileData.forEach(System.out::println);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void writeDataToFile(String fileName) {
        //todo: write data into file
    }

    public boolean canClick(int row, int col) {
        return gamePanel.canClickGrid(row, col, currentPlayer);
    }


}
